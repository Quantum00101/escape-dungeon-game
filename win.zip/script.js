function chooseDoor(door) {
    const gameText = document.getElementById("game-text");
    const choices = document.getElementById("choices");
    const restart = document.getElementById("restart");

    if (door === 1) {
        gameText.textContent = "You enter Door 1 and find a treasure chest! You win!";
    } else if (door === 2) {
        gameText.textContent = "You enter Door 2 and find a dark corridor. You are lost forever. Game over.";
    } else if (door === 3) {
        gameText.textContent = "You enter Door 3 and fall into a pit filled with spikes. Game over.";
    }

    choices.style.display = "none";
    restart.style.display = "inline-block";
}

function restartGame() {
    document.getElementById("game-text").textContent = "You wake up in a dark dungeon. In front of you, there are three doors.";
    document.getElementById("choices").style.display = "block";
    document.getElementById("restart").style.display = "none";
}
